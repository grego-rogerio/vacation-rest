package com.employee.vacationrest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.employee.vacationrest.model.Equipe;

public interface EquipeRepository extends JpaRepository<Equipe, Integer>{

}
