package com.employee.vacationrest.model;

import java.util.Date;

public class Ferias {
	private Integer idFerias;
	private Funcionario funcionario;
	private Date dataInicio;
	private Date dataFim;

	public Integer getIdFerias() {
		return idFerias;
	}

	public void setIdFerias(Integer idFerias) {
		this.idFerias = idFerias;
	}

	public Funcionario getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}

	public Date getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio;
	}

	public Date getDataFim() {
		return dataFim;
	}

	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}

	@Override
	public String toString() {
		return this.funcionario.toString() + " " + this.dataInicio.toString() + " " + this.dataFim.toString();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (obj instanceof Ferias) {
			Ferias ferias = (Ferias) obj;
			if (ferias.funcionario.equals(this.funcionario) && ferias.dataInicio.equals(this.dataInicio)
					&& ferias.dataFim.equals(dataFim)) {
				return true;
			} else {
				return false;
			}
		}

		return super.equals(obj);
	}

	@Override
	public int hashCode() {
		return idFerias * 36;
	}

}
