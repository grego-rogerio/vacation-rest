package com.employee.vacationrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VacationRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(VacationRestApplication.class, args);
	}

}
