package com.employee.vacationrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employee.vacationrest.model.Equipe;
import com.employee.vacationrest.repository.EquipeRepository;

@RestController
@RequestMapping(value = "/api")
public class EquipeController {
	@Autowired
	EquipeRepository equipeRepository;

	@GetMapping("/equipes")
	public List<Equipe> listaEquipes(){
		return equipeRepository.findAll();
	}
	
}
